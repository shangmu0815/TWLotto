Google Analytics Android SDK version 2.0 beta 3

Copyright 2009 - 2012 Google, Inc. All rights reserved.

================================================================================
DESCRIPTION:

This SDK provides developers with the capability to use Google Analytics
to track Android application usage.

The SDK is packaged as a jar file, a zip file containing javadocs, a file
Changelog.txt and this file (Readme.txt).

Details on how to use this SDK can be found at:

   http://developers.google.com/analytics/devguides/collection/android/v2.

================================================================================
BUILD REQUIREMENTS:

Android SDK 2.1+

================================================================================
RUNTIME REQUIREMENTS:

Android SDK 2.1+

================================================================================
PACKAGING LIST:

libGoogleAnalyticsV2.jar
javadocs.zip
Changelog.txt
Readme.txt
